# Pokédex Interactiva i Joc de Pokémon

Aquesta és una aplicació web interactiva completa desenvolupada amb **HTML5**, **Bootstrap 5.3**, **CSS3** i **JavaScript (ES6)** que consumeix dades directament de la [PokéAPI](https://pokeapi.co/).

## 🚀 Característiques

- **Pokédex Completa:** Inclou els primers 151 Pokémon amb imatges d'alta qualitat (*Official Artwork*).
- **Cercador i Filtres:** Cerca instantània per nom o número, i filtratge per tipus en català.
- **Modal Interactiu:** Informació detallada sobre estadístiques base, habilitats, pes, alçada i la seva línia evolutiva.
- **Favorits:** Gestió de la teva pròpia llista de favorits desada en local (`localStorage`).
- **Minijoc "Quin és aquest Pokémon?":** Joc de preguntes interactiu amb efecte de silueta i comptador de puntuació i ràtxes.
- **Mode Clar / Fosc:** Selector de tema integrat amb Bootstrap 5.3.

## 🛠️ Com utilitzar o publicar a GitHub Pages

1. Descomprimeix aquest fitxer `.zip`.
2. Obre el fitxer `index.html` directament al teu navegador per provar-ho localment.
3. Per publicar a **GitHub Pages**:
   - Crea un repositori a GitHub (ex: `pokedex-web`).
   - Sobeix tots els fitxers (`index.html`, `style.css`, `script.js`, `README.md`).
   - Ves a `Settings` > `Pages` al teu repositori.
   - A *Source*, selecciona la branca `main` o `master` i desa.
   - En pocs segons tindràs la web publicada!
